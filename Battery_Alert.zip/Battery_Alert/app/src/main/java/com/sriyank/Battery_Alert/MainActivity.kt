package com.Battery_Alert

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.drawable.AnimationDrawable
import android.media.Ringtone
import android.media.RingtoneManager
import android.os.BatteryManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatDelegate
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

	lateinit var textView: TextView
	lateinit var editText: EditText
	lateinit var btn_Stop: Button
	lateinit var btn_submit:android.widget.Button
	lateinit var ringtone: Ringtone

	//int pval = 0;
	var battery_per_enter = 0
	var value = ""

	private lateinit var frameAnimation: AnimationDrawable

	override fun onCreate(savedInstanceState: Bundle?) {
		super.onCreate(savedInstanceState)
		setContentView(R.layout.activity_main)

		AppCompatDelegate.setDefaultNightMode(AppCompatDelegate.MODE_NIGHT_NO)

		textView = findViewById<TextView>(R.id.battery_message)
		editText = findViewById<EditText>(R.id.enter_battery_per)
		btn_submit = findViewById<Button>(R.id.submit_battery)
		btn_Stop = findViewById<Button>(R.id.stop_ring)

		ringtone = RingtoneManager.getRingtone(
			applicationContext,
			RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
		)


		btn_submit.setOnClickListener(View.OnClickListener { view: View? ->
			value = editText.getText().toString()
			battery_per_enter = value.toInt()
			if (battery_per_enter < 0) {
				Toast.makeText(
					applicationContext,
					"""
						Enter battery % 
						value between 0% to 100%
						""".trimIndent(),
					Toast.LENGTH_SHORT
				).show()
				textView.setText(editText.getText().toString())
			} else if (battery_per_enter > 100) {
				Toast.makeText(
					applicationContext,
					"""
						Enter battery % 
						value between 0% to 100%
						""".trimIndent(),
					Toast.LENGTH_SHORT
				).show()
				textView.setText(editText.getText().toString() + "%")
			} else {
				textView.setText(editText.getText().toString() + "%")
				val broadcastReceiver: BroadcastReceiver = object : BroadcastReceiver() {
					override fun onReceive(context: Context, intent: Intent) {
						val intBatteryLevel = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, 0)
						//Toast.makeText(getApplicationContext(), "Battery Level : " + intBatteryLevel.toString(), Toast.LENGTH_SHORT).show();
						if (intBatteryLevel == battery_per_enter) {
							ringtone.play()
							//Toast.makeText(getApplicationContext(), "SAME BATTERY %", Toast.LENGTH_SHORT).show();
						}
					}
				}
				registerReceiver(broadcastReceiver, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
			}
		})

		btn_Stop.setOnClickListener(View.OnClickListener { view: View? ->
			//value = "";
			battery_per_enter = 0
			ringtone.stop()
		})

	}

	override fun onStart() {
		super.onStart()

		myImageView.setBackgroundResource(R.drawable.battery_animation_list)

		frameAnimation = myImageView.background as AnimationDrawable
		frameAnimation.start()
	}

	/* Button click event handler */
	fun startStopAnimation(view: View) {

		if (frameAnimation.isRunning)
			frameAnimation.stop()
		else
			frameAnimation.start()
	}
}